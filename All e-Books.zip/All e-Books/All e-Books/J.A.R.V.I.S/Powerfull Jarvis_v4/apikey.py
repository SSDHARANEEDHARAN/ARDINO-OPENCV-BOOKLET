# Storing the API key as a string variable for accessing the OpenAI API
api_data = "Your API Key"
